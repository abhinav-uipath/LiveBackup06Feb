import { LightningElement, api } from 'lwc';




export default class Ei_NI_websitecontactpagebutton extends LightningElement {

   @api buttonName1 = 'xyz1 button';
   @api getusertargetvalue1= 'https://www.google.com/';

   @api buttonName2 = 'xyz2 button';
   @api getusertargetvalue2= 'https://www.google.com/';

   @api buttonName3 = 'xyz3 button';
   @api getusertargetvalue3= 'https://www.google.com/';

   // @api dynamictarget = this.getusertargetvalue == 'External' ? '_blank': '_parent';




   handleButtonClick(){

      console.log('handleButtonClicked !!');

   }

}
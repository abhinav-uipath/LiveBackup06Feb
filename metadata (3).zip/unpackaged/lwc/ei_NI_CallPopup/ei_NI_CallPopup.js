import { LightningElement } from 'lwc';

export default class Ei_NI_CallPopup extends LightningElement {
    showModal = false;

    openModal() {
        this.showModal = true;
    }

    closeModal() {
        this.showModal = false;
    }
}
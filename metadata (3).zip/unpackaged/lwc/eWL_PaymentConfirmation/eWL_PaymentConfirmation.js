import { LightningElement,track } from 'lwc';
import EWIVPlus_Link from '@salesforce/label/c.EWIVPlus_Link';

export default class EWL_PaymentConfirmation extends LightningElement {
    accessCode1;
    @track urlparam;
    @track bool = false;
    connectedCallback(){
        setTimeout(() => { window.history.forward();  }, 0);
        
        const queryString = window.location.search;
        console.log('queryString => ' + queryString);
        const urlParams = new URLSearchParams(queryString);
        console.log('urlParams => ' + urlParams);
        const caseId = urlParams.get('caseId');
        console.log('caseId => ' + caseId);
        const accessCode = urlParams.get('accessCode');
        this.accessCode = accessCode;
        this.accessCode1 = this.accessCode;
        console.log('accessCode => ' + accessCode);
    }
    handleclick(){
        window.location.href =  EWIVPlus_Link+this.accessCode1;

        // let currentURL = window.location.href;
        // console.log('currentURL => ' + currentURL);
        // let homeURL = currentURL.split('/ewinsured/s');
        // console.log('homeURL => ' + homeURL[0]);
        // let redirectToURL = homeURL[0]+'/ewinsured/s/ewiagllaccountdetails?accessCode='+this.accessCode1;
        // this.urlparam = this.redirectToURL;
        // console.log('redirectToURL => ' + redirectToURL);
        // window.location.href = redirectToURL;
    }
}